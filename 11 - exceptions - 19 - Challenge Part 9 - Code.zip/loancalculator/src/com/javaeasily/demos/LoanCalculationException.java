package com.javaeasily.demos;

public class LoanCalculationException extends Exception {
    public LoanCalculationException(String message) {
        super(message);
    }
}
