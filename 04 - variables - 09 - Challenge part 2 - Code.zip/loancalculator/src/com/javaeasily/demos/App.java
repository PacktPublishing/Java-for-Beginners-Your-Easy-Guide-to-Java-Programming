package com.javaeasily.demos;

public class App {
    public static void main(String[] args) {
        System.out.println("Loan Calculator");

        int amount = 1000;
        int years = 5;
        double interestRate = 1.5;
    }
}
